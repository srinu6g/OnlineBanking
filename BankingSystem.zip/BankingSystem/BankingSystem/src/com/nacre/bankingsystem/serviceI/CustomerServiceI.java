package com.nacre.bankingsystem.serviceI;

public interface CustomerServiceI {

}
