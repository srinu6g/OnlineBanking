package com.nacre.bankingsystem.serviceI.serviceImpl;

import com.nacre.bankingsystem.serviceI.CustomerServiceI;

public class CustomerServiceImpl implements CustomerServiceI{

}
