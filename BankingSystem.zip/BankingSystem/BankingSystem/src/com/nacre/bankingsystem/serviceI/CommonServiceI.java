package com.nacre.bankingsystem.serviceI;

import com.nacre.bankingsystem.dto.LoginDTO;

public interface CommonServiceI {
	public String getLogin(LoginDTO login);
}
