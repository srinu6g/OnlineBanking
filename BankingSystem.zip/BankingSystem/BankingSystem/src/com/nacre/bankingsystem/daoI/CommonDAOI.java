package com.nacre.bankingsystem.daoI;

import com.nacre.bankingsystem.dto.LoginDTO;

public interface CommonDAOI {
	public String getLogin(LoginDTO login);
}
