package com.nacre.bankingsystem.daoI.daoImpl;

import com.nacre.bankingsystem.daoI.CustomerDAOI;

public class CustomerDAOImpl implements CustomerDAOI{

}
