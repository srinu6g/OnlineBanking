package com.nacre.bankingsystem.daoI;

public interface CustomerDAOI {

}
