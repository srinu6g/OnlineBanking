package com.nacre.bankingsystem.delegate;

public class CustomerDelegate {

}
