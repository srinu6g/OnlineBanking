$(document).ready(function() {
	$(".CheckingImg");
});